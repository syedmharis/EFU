from urllib.request import Request
from django.shortcuts import render
import random
import datetime
from matplotlib import image
import mysql.connector
# Create your views here.
from django.http import HttpResponse
from .models import partsclass
from django.core.files.storage import FileSystemStorage


#data base details:


#important variable:
policy_no = '00000000000000000'
subpolicy_no=''
lossno = '00000000000000000'



def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")

def home(request):
    return render(request,'login.html') #'login.html'

def add(request):
    return render(request,"result.html")

def login(request):
    db_connection = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
        )
    my_database = db_connection.cursor()
    sql_statement = "SELECT * FROM claimlogin"
    my_database.execute(sql_statement)
    output = my_database.fetchall()
    username = str(request.POST["username"])
    password = str(request.POST["userpassword"])
    res = (username,password)   
    if res in output:
        db_connection.close()
        return render(request,"selection_1.html")
    else:
        db_connection.close()
        return render(request,"login.html")
def newclient(request):
    return render(request,'clientregistration.html')
def client_registration(request):
    date = datetime.datetime.now()
    global policy_no 
    # random policy number generate:
    number = int(random.uniform(0000000000,9999999999))
    policy_no = f'{number}/{date.month}/{date.year}'
    db_connection = mysql.connector.connect(

        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
        )
    my_database = db_connection.cursor()
    firstname = str(request.POST["firstname"])
    lastname = str(request.POST["lastname"])
    cnic = int(request.POST["cnic"])
    number = int(request.POST["number"])
    address = str(request.POST["address"])
    gender = str(request.POST["gender"])
    date = str(request.POST["date"])
    img = request.FILES['images']
    fss =FileSystemStorage()
    img.name = f'{policy_no[:10]}.jpg'
    file = fss.save(img.name,img)
    file_url = fss.url(file)
    destination = f'F:/efu/efu/efuproject{file_url}'
    # sql_statement = "INSERT INTO clientpics VALUES(%s,%s);"
    # res = (policy_no,image)
    # my_database.execute(sql_statement,res)
    # txt = str(image).split('.')
    # picture = Image.open(image)
    # picture = picture.save('F:\\efu\\efuproject\\datastoring\\'+str(policy_no)+'.'+txt[1])
    # sql_statement = "INSERT INTO clientpics VALUES (%s,%s);"
    # res = (policy_no,str(image))
    # my_database.execute(sql_statement,res)
    # db_connection.commit()
    sql_statement = "INSERT INTO client VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s);"
    res =(firstname,lastname,address,cnic,number,gender,date,destination,policy_no)
    #sql_statement = "SELECT * FROM members;"
    my_database.execute(sql_statement,res)
    db_connection.commit()
    db_connection.close()
    return render(request,'purchasepolicy.html',{"date":date,"policyno":policy_no,"number":'+92'+str(number), 'imgurl':file_url})

def purchasepolicy(request):
    db_connection = mysql.connector.connect(

        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
        )   
    my_database = db_connection.cursor()
    #number = str(request.POST["number"])
    global policy_no
    sql_statement = "INSERT INTO policy VALUES (%s,%s,%s);"
    sql_statement1= "SELECT cellno,date FROM client WHERE policyno = %s"
    my_database.execute(sql_statement1,(policy_no,))
    output = my_database.fetchall()
    output = output[0]
    res =(str(output[0]),policy_no,str(output[1]))
    my_database.execute(sql_statement,res)
    sql_query = "SELECT * FROM branch"
    my_database.execute(sql_query)
    output = my_database.fetchall()
    branch = []
    for i in output:
        branch.append(str(i[0])+'/'+str(i[1]))
    sql_query = "SELECT firstname,lastname from client WHERE policyno = %s"
    my_database.execute(sql_query,(policy_no,))
    output = my_database.fetchall()
    output = output[0]
    db_connection.commit()
    db_connection.close()
    return render(request,'car_details.html',{"branchs":branch,"name":str(output[0])+' '+str(output[1])})

def car_details(request):
        db_connection = mysql.connector.connect(

        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
        )
        global policy_no
        temp = policy_no
        my_database = db_connection.cursor()
        registration_no =str(request.POST["registrationno"])
        engineno = str(request.POST["engineno"])
        chasisno = str(request.POST["chasisno"])
        sum = str(request.POST["sum"])
        company = str(request.POST["company"])
        modelname = str(request.POST["modelname"])
        modelnumber = str(request.POST["modelnumber"])
        bodytype = str(request.POST["bodytype"])
        seatingcapacity = int(request.POST["seatingcapacity"])
        color = str(request.POST["color"])
        cubiccapacity = str(request.POST["cubiccapacity"])
        img = request.FILES['images1']
        fss =FileSystemStorage()
        img.name = f'{temp[:10]}_car.jpg'
        file = fss.save(img.name,img)
        file_url = fss.url(file)
        destination = f'F:/efu/efu/efuproject{file_url}'
        sql_statement = "INSERT INTO cardetails VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);"
        res = (sum,registration_no,engineno,chasisno,policy_no,company,modelnumber,modelname,bodytype,color,cubiccapacity,seatingcapacity,destination)
        my_database.execute(sql_statement,res)
        db_connection.commit()
        db_connection.close()
        policy_no = '00000000000000000'      
        return render(request,'selection_1.html')
def preclient(request):
    return render(request,'clientinfo.html')
def clientinfo(request):
    db_connection = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
    )
    my_database = db_connection.cursor()
    global policy_no
    policy_no = str(request.POST['policyno'])
    global subpolicy_no 
    subpolicy_no = policy_no
    sql_statement = "SELECT * FROM client WHERE policyno = %s ;"
    my_database.execute(sql_statement,(policy_no,))
    output = my_database.fetchall()
    i = output[0]
    firstname = i[0]
    lastname = i[1]
    address = i[2]
    cnic = i[3]
    cellno = i[4]
    gender = i[5]
    date = i[6]
    status = 'active'
    db_connection.close()
    return render(request,'show_cd.html',{"policyno":policy_no,"firstname":firstname,"lastname":lastname,"cnic":cnic,"contactnumber":cellno,"gender":gender,"address":address,"date":date,"status":status})
def postclientdetails(request):
    global policy_no
    return render(request,'selection_2.html')
def lossopen(request):
        db_connection = mysql.connector.connect(

        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
        )
        my_database = db_connection.cursor()
        global policy_no
        global lossno
        #policy number
        sql_query = "SELECT * from client where policyno = %s"
        res = (policy_no,)
        my_database.execute(sql_query,res)
        output = my_database.fetchall()
        i = output[0]
        cellno = i[4]
        certno = str(request.POST["certificateno"])
        date = str(request.POST["date"])
        branch = str(request.POST["branchname"]).split('/')
        sql_statement = "INSERT INTO lossopen VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"
        res = (cellno,date,'active',lossno,certno,branch[0],branch[1],policy_no)
        my_database.execute(sql_statement,res)
        db_connection.commit()
        sql_query = "SELECT * FROM surveyourdetails;"
        my_database.execute(sql_query)
        output = my_database.fetchall()
        surveyour = []
        for i in output:
            surveyour.append(f'{i[0]}\{i[1]}')
        db_connection.close()
        return render(request,'surveyourdetails.html',{"sur":surveyour,"lossno":lossno})
####edited
def loss(request):
    global policy_no
    policy = policy_no
    db_connection = mysql.connector.connect(

    host="localhost",
    user="root",
    passwd="lh5080",
    database="motorclaimsys"
    )
    global lossno
    date = datetime.datetime.now()
    number = int(random.uniform(0000000000,9999999999))
    lossno = f'{number}/{date.month}/{date.year}'
    my_database = db_connection.cursor()
    sql_query = "SELECT cellno from client where policyno = %s"
    res = (policy_no,)
    my_database.execute(sql_query,res)
    output = my_database.fetchall()
    output = output[0]
    number = output[0]
    sql_query = "SELECT * FROM branch"
    my_database.execute(sql_query)
    output = my_database.fetchall()
    branch = []
    for i in output:
        branch.append(str(i[0])+'/'+str(i[1]))
    db_connection.close()
    return render(request,'lossopen.html',{"lossno":lossno,"policyno":policy,"number":"+92" + str(number),"branchs":branch})

####edited.

def survey(request):
    global policy_no
    policy = policy_no
    global lossno
    db_connection = mysql.connector.connect(

        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
        )
    my_database = db_connection.cursor()
    sql_query = "SELECT name,id FROM surveyourdetails WHERE lossno = %s;"
    res = (lossno,)
    my_database.execute(sql_query,res)
    output = my_database.fetchall()
    output=output[0]
    dic = {
        "policyno":policy,
        "name" :output[0],
        "id" :output[1],
        "claimno":lossno,
    }
    return render(request,'survey_form.html',dic)

def surveyour_details(request):
    db_connection = mysql.connector.connect(

        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
        )  
    global policy_no
    policy_no = policy_no
    global lossno
    my_database = db_connection.cursor()
    name = str(request.POST["surveyorname"])
    id = str(request.POST["surveyourid"])
    carmake = str(request.POST["carmake"])
    regno = str(request.POST["regno"])
    client = str(request.POST["client"])
    cell = str(request.POST["cell" ])
    parts = str(request.POST["text"])
    workshop = str(request.POST["workshop"])
    remarks = str(request.POST["remarks"])
    sql_statement = "INSERT INTO surveyourdetails VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    res = (name,id,lossno,carmake,regno,client,cell,parts,workshop,remarks)
    my_database.execute(sql_statement,res)
    db_connection.commit()
    db_connection.close()
    return render(request,'selection_2.html')










def surveyform(request):
    db_connection = mysql.connector.connect(

        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
    )
    my_database = db_connection.cursor()
    global policy_no
    policy_no = policy_no
    global subpolicy_no
    subpolicy_no = policy_no
    global lossno
    sql_query = "SELECT name,id FROM surveyourdetails WHERE lossno = %s;"
    res = (lossno,)
    my_database.execute(sql_query,res)
    output = my_database.fetchall()
    survey=output[0]
    dic = {
        "policyno":policy_no,
        "name" :survey[0]
    }
    surveyplace= str(request.POST["surveyplace"])
    estimatedlabor = str(request.POST["estimatedlabor"])
    settledlabor = str(request.POST["settledlabor"])
    amountpaid = str(request.POST["amountpaid"])
    noofparts = int(request.POST["totalparts1"])
    sql_query = "INSERT INTO parts VALUES(%s,%s,%s,%s,%s);"
    for i in range(noofparts):
        part = str(request.POST["part"+str(i+1)])
        cost = str(request.POST["cost"+str(i+1)])
        workshop = str(request.POST["workshop"+str(i+1)])
        task = str(request.POST["task"+str(i+1)])
        res = (lossno,part,task,cost,workshop)
        my_database.execute(sql_query,res)    
    inspection_date = str(request.POST["inspectiondate"])
    dateofloss = str(request.POST["dateofloss"])
    sql_statement = "INSERT INTO survey VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    res = (dateofloss,surveyplace,dic["name"],estimatedlabor,settledlabor,noofparts,lossno,amountpaid,workshop,policy_no)    
    my_database.execute(sql_statement,res)
    db_connection.commit()
    db_connection.close()
    return render(request,'selection_4.html')


    
def secondaryreport(request):
    global subpolicy_no
    policy_no = subpolicy_no
    return render(request,'secondaryreport.html',{"policyno":policy_no})

def secondaryreport1(request):
    global subpolicy_no
    policy_no = subpolicy_no
    db_connection = mysql.connector.connect(

        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
    )  
    my_database = db_connection.cursor()
    details = str(request.POST["details"])
    about = str(request.POST["About"])
    date = str(request.POST["date"])
    status = "active"
    sql_statement = "INSERT INTO secondaryreport VALUES(%s,%s,%s,%s)"
    res = (policy_no,details,about,date)
    my_database.execute(sql_statement,res)
    db_connection.commit()
    db_connection.close()
    return render(request,'secondaryreport1.html',{"policyno":policy_no,"details":details,"About":about,"date":date})  


def preprimaryreport(request):
    global subpolicy_no
    policy_no = subpolicy_no
    global lossno
        
    db_connection = mysql.connector.connect(

        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
    )
    my_database = db_connection.cursor()    
    query = 'SELECT engine_no,reg_no,chasis_no,make,model FROM cardetails WHERE policyno = %s'
    my_database.execute(query,(policy_no,))
    cardetails = my_database.fetchall()
    cardetails=cardetails[0]
    query = 'SELECT firstname,lastname,cellno,cnic FROM client WHERE policyno = %s'
    my_database.execute(query,(policy_no,))
    client = my_database.fetchall()
    client = client[0]
    query = 'SELECT date,status,lossno,certificateno,branch FROM lossopen WHERE policyno = %s'
    my_database.execute(query,(policy_no,))
    loss = my_database.fetchall()
    loss = loss[0]
    query = 'SELECT estimated_labor,amountpaid,settled_labor,No_of_parts,claim_no,workshop,surveyourname,place FROM survey WHERE policyno = %s'
    my_database.execute(query,(policy_no,))
    survey = my_database.fetchall()
    survey = survey[0]
    query = 'SELECT cell,remarks FROM surveyourdetails WHERE lossno = %s'
    my_database.execute(query,(loss[2],))
    surveyour = my_database.fetchall()
    surveyour = surveyour[0]
    query = 'SELECT part,task,cost,workshop FROM parts WHERE lossno = %s'
    my_database.execute(query,(lossno,))
    part = my_database.fetchall()
    parts = []
    for i in part:
        parts.append(partsclass(i[0],i[1],i[2],i[3]))
    dic ={
        "engineno":cardetails[0],
        "regno" : cardetails[1],
        "chasisno" : cardetails[2],
        "make" : cardetails[3],
        "model" : cardetails[4],
        "contactperson" : client[0] + ' ' + client[1],
        "mobile" : client[3],
        "dateofloss" : loss[0],
        "dol" : loss[0],
        "date":datetime.datetime.now(),
        "status":loss[1],
        "policyno" :policy_no,
        "lossno" :loss[2],
        "certificateno" : loss[3],
        "branch" : loss[4],
        "driver" : client[0] + ' ' + client[1],
        "estimatedlabor" : survey[0],
        "amountpaid" : survey[1],
        "settledlabor" : survey[2],
        "noofpartsallowed" : survey[3],
        "claimno" :survey[4],
        "workshop1" : survey[5],
        "surveyor" :survey[6],
        "place" : survey[7],
        "remarks" : surveyour[1],
        "tel" : surveyour[0],
        "sdpart" : "--",
        "depreciation":"--",
        "signature":"--",
        "parts":parts
    }
    db_connection.close()
    return render(request,'primaryreportfinal.html',dic)

def back(request):
    global subpolicy_no
    return render(request,'selection_4.html')
def finish(request):
    global subpolicy_no
    global policy_no
    global lossno
    policy_no = subpolicy_no
    db_connection = mysql.connector.connect(

        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
    )
    my_database = db_connection.cursor()
    sql_statement = "DELETE FROM lossopen WHERE policyno = %s"
    res = (policy_no,)
    my_database.execute(sql_statement,res)
    sql_statement ="DELETE FROM parts WHERE lossno = %s"
    res = (lossno,)
    my_database.execute(sql_statement,res)
    db_connection.commit()
    db_connection.close()
    subpolicy_no=''
    policy_no = '00000000000000000'
    return render(request,'selection_1.html')

def predelclient(request):
    return render(request,"delclient.html")

def delclient(request):
    db_connection = mysql.connector.connect(

        host="localhost",
        user="root",
        passwd="lh5080",
        database="motorclaimsys"
    )
    my_database = db_connection.cursor()
    policy = str(request.POST["policyno"])
    sql_statement = "DELETE FROM client WHERE policyno = %s;"
    res = (policy,)
    my_database.execute(sql_statement,res)
    db_connection.commit()
    db_connection.close()
    return render(request,'selection_1.html')

