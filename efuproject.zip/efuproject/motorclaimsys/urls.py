from django.urls import path

from . import views

urlpatterns = [path('',views.home,name = 'home'),
path('login',views.login,name='login'),path('client_registration',views.client_registration,name='client_registration'),path('purchasepolicy',views.purchasepolicy,name='purchasepolicy'),path('car_details',views.car_details,name='car_details'),path('newclient',views.newclient,name='newclient'),path('preclient',views.preclient,name='preclient'),path('clientinfo',views.clientinfo,name='clientinfo'),path('postclientdetails',views.postclientdetails,name='postclientdetails'),
path('loss',views.loss,name='loss'),path('survey',views.survey,name='survey'),path('lossopen',views.lossopen,name='lossopen'),path('surveyour_details',views.surveyour_details,name='surveyour_details'),path('surveyform',views.surveyform,name='surveyform'),path('preprimaryreport',views.preprimaryreport,name='preprimaryreport'),path('secondaryreport',views.secondaryreport,name='secondaryreport'),path('secondaryreport1',views.secondaryreport1,name='secondaryreport1'),
path('back',views.back,name='back'),path('finish',views.finish,name='finish'),path('predelclient',views.predelclient,name='predelclient'),path('delclient',views.delclient,name='delclient')]