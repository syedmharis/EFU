from django.db import models

# Create your models here.

class partsclass:
    def __init__(self,part,task,cost,workshop):
        self.part = part
        self.task = task
        self.cost = cost
        self.workshop = workshop
